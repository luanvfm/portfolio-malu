# Portfólio — Maria Luiza (Jornalista)

Site vitrine, bilíngue (PT/EN), com estética **"Azulejo Recife"** — azuis do Recife Antigo com creme e dourado, tipografia editorial de jornal, prioridade ao visual sobre o texto. Imagens/vídeos entram depois via placeholders prontos.

## Direção visual
- **Paleta:** `#1d3557` (azul profundo), `#457b9d` (azul azulejo), `#e9c46a` (dourado), `#f1faee` (creme). Fundo creme, acentos azuis, dourado para destaques.
- **Tipografia:** display serifada editorial (ex.: DM Serif Display / Playfair) para manchetes + sans limpa (ex.: Work Sans) para corpo — cara de jornal moderno.
- **Textura:** detalhe sutil de padrão de azulejo em divisórias/rodapé; molduras finas douradas em cards.
- **Movimento:** animações discretas de entrada (fade/slide) via Motion, hover elegante nos cards de matéria.

## Estrutura de rotas
```text
/            Home (hero + destaques + números + áreas + prévia portfólio + Instagram + contato)
/sobre       Bio completa + foto + trajetória
/portfolio   Galeria de matérias/vídeos (Sport, Náutico, BetoCastTV, TVNova, Futsal)
/contato     E-mail, LinkedIn, Instagram @malu.informa
```
Cada rota com `head()` próprio (SEO). Header e footer compartilhados com seletor de idioma PT/EN.

## Fase 1 — Fundação e design system
- Configurar paleta Azulejo Recife como tokens em `src/styles.css` (light).
- Instalar/importar fontes (@fontsource), definir famílias display/corpo.
- Estrutura base de rotas, Header com nav + toggle de idioma, Footer com contatos e padrão de azulejo.
- Infra de i18n leve (dicionário PT/EN com contexto React) — textos curtos.

## Fase 2 — Home
- **Hero:** frase de impacto ("Jornalismo esportivo e cultura pernambucana") + CTA "Fale comigo", com espaço para foto/vídeo de fundo (placeholder).
- **Números de impacto:** cards (matérias produzidas, jogos cobertos, seguidores, clubes cobertos) — valores editáveis.
- **Áreas de atuação:** cards — Jornalismo Esportivo, Cultura Pernambucana, Repórter de Campo, Jornalismo & Marketing (Federação de Futsal).
- Prévia do portfólio + chamada para Instagram + faixa de contato.

## Fase 3 — Portfólio de matérias
- Galeria em grid/masonry com cards de mídia (thumb + veículo + título + tag esportiva/cultura).
- Placeholders bem definidos para imagens e vídeos (proporções e legendas) para você preencher depois.
- Filtro por categoria (Esporte / Cultura / TV / Federação) e por veículo.

## Fase 4 — Sobre + Instagram
- Página **Sobre:** foto profissional (placeholder), bio, mini linha do tempo (Sport/Náutico–BetoCastTV, TVNova, Federação Pernambucana de Futsal).
- **Bloco Instagram (@malu.informa):** grade de posts (placeholders) com destaque para cultura pernambucana e futebol + botão "Seguir".

## Fase 5 — Contato + finalização
- Página **Contato:** cards grandes para E-mail, LinkedIn e Instagram @malu.informa (links diretos), tom criativo mas profissional.
- SEO por rota, alt text, responsividade mobile, revisão de acessibilidade e polimento visual (azulejo, dourado, animações).

## Considerações para RH (incluídas)
- Botão/estrutura para **currículo em PDF** (baixar) — recomendado, fácil de adicionar.
- **Versão bilíngue PT/EN** desde a Fase 1.
- **Números de impacto** e **áreas de atuação** para leitura rápida por recrutadores.
- Placeholders claros de mídia para você inserir fotos/vídeos sem quebrar o layout.

## Detalhes técnicos
- TanStack Start + rotas em `src/routes/`, tokens em `src/styles.css`, componentes em `src/components/`.
- Fontes via `@fontsource`; animações com Motion.
- i18n via contexto React + dicionário local (sem backend). Nenhum backend necessário nesta fase.
